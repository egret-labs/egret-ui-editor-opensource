# Native Access to Mac OS-X FSEvents - Change-Log

## Version 0.0.1

  * Basic functionality

## Version 0.1.2

  * Finally made the Jump to node 0.8+ with this module.
  * Much more Event-Details

## Version 0.2.0

 * More or less complete rewrite to keep up with ever changing binary compile issues
 * Utilizing the ["Power of Nan"](http://npmjs.org/package/nan) (Thank you [rvag](https://github.com/rvag))
 